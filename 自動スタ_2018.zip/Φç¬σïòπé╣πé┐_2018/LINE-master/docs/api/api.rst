LineAPI
=======

Introduction
------------

This is a python wrapper of official LINE thirft API. There are other functions
which is not implemented to *line* like `kickoutFromGroup` things, so you can add
other API here and use it as your way.


LineAPI
-------

.. autoclass:: line.LineAPI
   :members:
   :private-members:
